-- MySQL dump 10.13  Distrib 5.6.13, for Linux (x86_64)
--
-- Host: localhost    Database: nsturesultnew
-- ------------------------------------------------------
-- Server version	5.6.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `examinees`
--

DROP TABLE IF EXISTS `examinees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examinees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(255) DEFAULT NULL,
  `roll_number` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examinees`
--

LOCK TABLES `examinees` WRITE;
/*!40000 ALTER TABLE `examinees` DISABLE KEYS */;
INSERT INTO `examinees` VALUES (1,'A',1001031,NULL,NULL),(2,'A',1001032,NULL,NULL);
/*!40000 ALTER TABLE `examinees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examinees_details`
--

DROP TABLE IF EXISTS `examinees_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examinees_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `ssc_roll` float DEFAULT NULL,
  `ssc_gpa` float DEFAULT NULL,
  `hsc_roll` float DEFAULT NULL,
  `hsc_gpa` float DEFAULT NULL,
  `quota` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `examinee_id` int(11) DEFAULT NULL,
  `result_id` int(11) DEFAULT NULL,
  `results_details_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_examinees_details_on_examinee_id` (`examinee_id`),
  KEY `index_examinees_details_on_result_id` (`result_id`),
  KEY `index_examinees_details_on_results_details_id` (`results_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examinees_details`
--

LOCK TABLES `examinees_details` WRITE;
/*!40000 ALTER TABLE `examinees_details` DISABLE KEYS */;
INSERT INTO `examinees_details` VALUES (1,'Mashpy','Abul Basher',100123,5,200004,5,'FF',NULL,NULL,1,1,1),(2,'Robiul','Zamil Ahmed',100023,4,322008,5,'NO',NULL,NULL,2,2,2);
/*!40000 ALTER TABLE `examinees_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nstuseatplans`
--

DROP TABLE IF EXISTS `nstuseatplans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nstuseatplans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `center` varchar(255) DEFAULT NULL,
  `roll_start` int(11) DEFAULT NULL,
  `roll_end` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nstuseatplans`
--

LOCK TABLES `nstuseatplans` WRITE;
/*!40000 ALTER TABLE `nstuseatplans` DISABLE KEYS */;
INSERT INTO `nstuseatplans` VALUES (1,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','নোয়াখালী সরকারী কলেজ (নতুন ক্যাম্পাস), মাইজদী কোর্ট,  নোয়াখালী',10001,11394,NULL,NULL,NULL),(3,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','নোয়াখালী সরকারী মহিলা কলেজ, মাইজদী কোর্ট, নোয়াখালী',11395,12394,NULL,NULL,NULL),(4,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','সোনাপুর ডিগ্রী কলেজ, সোনাপুর, নোয়াখালী ',12395,13114,NULL,NULL,NULL),(6,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','কারামাতিয়া আলিয়া মাদ্রাসা, সোনাপুর, নোয়াখালী ',13115,13714,NULL,NULL,NULL),(7,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','প্রাইমারী টিচার্স ট্রেনিং ইন্সিস্টিউট (পিটিআই), মাইজদীকোর্ট, নোয়াখালী',13715,14114,NULL,NULL,NULL),(8,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','মাইজদী পাবলিক কলেজ, মাইজদীকোর্ট, নোয়াখালী',14115,14374,NULL,NULL,NULL),(9,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','নোয়াখালী জিলা স্কুল, মাইজদী কোর্ট, নোয়াখালী',14375,15390,NULL,NULL,NULL),(10,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','হরিনারায়নপুর উচ্চ বিদ্যালয়, মাইজদীকোর্ট, নোয়াখালী',15391,15990,NULL,NULL,NULL),(11,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','নোয়াখালী সরকারী বালিকা উচ্চ বিদ্যালয়, মাইজদী কোর্ট, নোয়াখালী ',15991,16815,NULL,NULL,NULL),(12,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','অরুন চদ্র উচ্চ বিদ্যালয়, মাইজদীকোর্ট, নোয়াখালী',16816,17315,NULL,NULL,NULL),(13,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','পৌর কল্যান উচ্চ বিদ্যালয়, মাইজদী কোর্ট, নোয়াখালী',17316,17765,NULL,NULL,NULL),(14,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','আহমাদিয়া আদর্শ উচ্চ বিদ্যালয়, উত্তর সোনাপুর, নোয়াখালী',17766,18145,NULL,NULL,NULL),(15,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','আল ফারুক একাডেমি , মাইজদীকোর্ট , নোয়াখালী',18146,18675,NULL,NULL,NULL),(16,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','মাইজদী বালিকা বিদ্যানিকেতন, মাইজদীকোর্ট, নোয়াখালী',18676,19125,NULL,NULL,NULL),(17,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','এম এ রশিদ উচ্চ বিদ্যালয়, মাইজদীকোর্ট, নোয়াখালী',19126,19455,NULL,NULL,NULL),(18,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','মাইজদী গার্লস একাডেমি, মাইজদীকোর্ট, নোয়াখালী',19456,19655,NULL,NULL,NULL),(19,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','বেগমগঞ্জ কারিগরি উচ্চ বিদ্যালয়, বেগমগঞ্জ, নোয়াখালী',19966,20365,NULL,NULL,NULL),(20,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','বেগমগঞ্জ পাইলট উচ্চ বিদ্যালয়, বেগমগঞ্জ, নোয়াখালী',20366,20855,NULL,NULL,NULL),(21,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','একলাশপুর উচ্চ বিদ্যালয়, বেগমগঞ্জ, নোয়াখালী ',20856,21455,NULL,NULL,NULL),(22,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','টেক্সটাইল ইঞ্জিনিয়ারিং কলেজ, বেগমগঞ্জ, নোয়াখালী',21456,21855,NULL,NULL,NULL),(23,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','বেগমগঞ্জ কারিগরি উচ্চ বিদ্যালয়, বেগমগঞ্জ, নোয়াখালী',21856,22155,NULL,NULL,NULL),(24,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','নোয়াখালী বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয়, সোনাপুর, নোয়াখালী',22156,23714,NULL,NULL,NULL),(25,'A','২৬ ডিসেম্বর, সকাল ১০:৩০ - ১২: ০০ টা','জালাল উদ্দিন কলেজ, বেগমগঞ্জ, নোয়াখালী',19656,19965,NULL,NULL,NULL),(26,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','নোয়াখালী সরকারী কলেজ (নতুন ক্যাম্পাস), মাইজদী কোর্ট, নোয়াখালী',30001,31394,NULL,NULL,NULL),(27,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','নোয়াখালী সরকারী মহিলা কলেজ,মাইজদী কোর্ট, নোয়াখালী',31395,32394,NULL,NULL,NULL),(28,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','সোনাপুর ডিগ্রী কলেজ, সোনাপুর, নোয়াখালী',32395,33060,NULL,NULL,NULL),(29,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','কারামাতিয়া আলিয়া মাদ্রাসা, সোনাপুর, নোয়াখালী',33061,33660,NULL,NULL,NULL),(30,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','প্রাইমারী টিসার্স ট্রেনিং ইনিস্টিটিউট (পি টি আই), মাইজদী কোর্ট, নোয়াখালী',33661,34060,NULL,NULL,NULL),(31,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','নোয়াখালী জিলা স্কুল, মাইজদী কোর্ট, নোয়াখালী',34061,35076,NULL,NULL,NULL),(32,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','নোয়াখালী সরকারী বালিকা বিদ্যালয়, মাইজদী কোর্ট, নোয়াখালী',35077,35901,NULL,NULL,NULL),(33,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','হরিনারায়নপুর উচ্চ বিদ্দালয়,মাইজদী কোর্ট, নোয়াখালী',35902,36501,NULL,NULL,NULL),(34,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','অরুনচন্দ্র উচ্চ বিদ্যালয়, মাইজদী বাজার, নোয়াখালী',36502,37001,NULL,NULL,NULL),(35,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','পৌর কল্যাণ উচ্চ বিদ্দালয়,মাইজদী কোর্ট, নোয়াখালী',37002,37451,NULL,NULL,NULL),(37,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','আহমদিয়া আদর্শ উচ্চ বিদ্যালয়, উত্তর সোনাপুর, নোয়াখালী',37452,37831,NULL,NULL,NULL),(38,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','আল ফারুক একাডেমি, মাইজদী কোর্ট, নোয়াখালী',37832,38361,NULL,NULL,NULL),(39,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','মাইজদী বালিকা নিকেতন, মাইজদী কোর্ট, নোয়াখালী',38362,38811,NULL,NULL,NULL),(40,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','এম এ রশিদ উচ্চ বিদ্দালয়,মাইজদী কোর্ট, নোয়াখালী',38812,39141,NULL,NULL,NULL),(41,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','জালাল উদ্দিন কলেজ, বেগমগঞ্জ, নোয়াখালী',39142,39451,NULL,NULL,NULL),(42,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','বেগমগঞ্জ কারিগরী উচ্চ বিদ্যালয়, বেগমগঞ্জ, নোয়াখালী',39452,39851,NULL,NULL,NULL),(43,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','বেগমগঞ্জ পাইলট উচ্চ বিদ্দালয়,বেগমগঞ্জ, নোয়াখালী',39852,40341,NULL,NULL,NULL),(44,'B','২৭ ডিসেম্বর, সকাল ১০:৩০ - ১২:৩০ টা','নোয়াখালী বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয়, সোনাপুর, নোয়াখালী',40342,41900,NULL,NULL,NULL),(45,'C','২৬ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী সরকারী কলেজ (নতুন ক্যাম্পাস), মাইজদী কোর্ট,  নোয়াখালী',50001,51394,NULL,NULL,NULL),(46,'C','২৬ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী সরকারী মহিলা কলেজ, মাইজদী কোর্ট, নোয়াখালী ',51395,52394,NULL,NULL,NULL),(47,'C','২৬ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী সরকারী বালিকা উচ্চ বিদ্যালয়, মাইজদী কোর্ট, নোয়াখালী',52395,52840,NULL,NULL,NULL),(48,'C','২৬ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয়, সোনাপুর, নোয়াখালী',52841,54399,NULL,NULL,NULL),(49,'D','২৭ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী সরকারী কলেজ (নতুন ক্যাম্পাস), মাইজদী কোর্ট,  নোয়াখালী',80001,81394,NULL,NULL,NULL),(50,'D','২৭ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী সরকারী মহিলা কলেজ, মাইজদী কোর্ট, নোয়াখালী',81395,82394,NULL,NULL,NULL),(51,'D','২৭ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী সরকারী বালিকা উচ্চ বিদ্যালয়, মাইজদী কোর্ট, নোয়াখালী',82395,83040,NULL,NULL,NULL),(52,'D','২৭ ডিসেম্বর, বিকাল ৩:০০ - ৪:০০','নোয়াখালী বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয়, সোনাপুর, নোয়াখালী',83041,84599,NULL,NULL,NULL);
/*!40000 ALTER TABLE `nstuseatplans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marks` float DEFAULT NULL,
  `merit` int(11) DEFAULT NULL,
  `list` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `results`
--

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` VALUES (1,200,1,'Main_list',NULL,NULL),(2,32,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `results_details`
--

DROP TABLE IF EXISTS `results_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `physics` float DEFAULT NULL,
  `chemistry` float DEFAULT NULL,
  `math` float DEFAULT NULL,
  `biology` float DEFAULT NULL,
  `ban_eng` float DEFAULT NULL,
  `bangla` float DEFAULT NULL,
  `english` float DEFAULT NULL,
  `analytical_ability` float DEFAULT NULL,
  `general_knowledge` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `results_details`
--

LOCK TABLES `results_details` WRITE;
/*!40000 ALTER TABLE `results_details` DISABLE KEYS */;
INSERT INTO `results_details` VALUES (1,30,40,50,60,44,55,87,23,87,NULL,NULL),(2,30,20,23,24,33,36,37,23,23,NULL,NULL);
/*!40000 ALTER TABLE `results_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20141221114622'),('20141221134449'),('20141221134841'),('20141221140057'),('20141221140323'),('20141221141010'),('20141221141144'),('20141221141329'),('20141222150712'),('20141222160735');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parameter` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-22 22:04:34
